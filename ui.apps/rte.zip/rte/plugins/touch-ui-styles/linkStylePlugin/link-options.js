(function ($) {
    "use strict";
 
    var _ = window._,
        Class = window.Class,
        CUI = window.CUI,
        REL_FIELD = "rel",
        RTE_LINK_DIALOG = "rtelinkdialog";

    if(CUI.rte.ui.cui.CuiDialogHelper.eaemExtended){
        return;
    }
 
    var EAEMLinkBaseDialog = new Class({
        extend: CUI.rte.ui.cui.LinkBaseDialog,
 
        toString: "EAEMLinkBaseDialog",

        anuragFieldCUI: null,

        anuragFieldSelectorString: ".coral-RichText-dialog--link span.coral-RichText-dialog-column--anuragField",

        customLinkStyleFieldCUI: null,

        customLinkStyleFieldSelectorString: ".coral-RichText-dialog--link span.coral-RichText-dialog-column--customLinkStyleField",

        initialize: function(config) {
            this.superClass.initialize.call(this, config);

            this.$rteDialog = this.$container.find("[data-rte-dialog=link]");

        	var styles = config["styles"];

            this.$rteDialog.append(getLinkRelOptionsHtml(toArray(styles)));

            if (!this.customLinkStyleFieldCUI) {
                this.customLinkStyleFieldCUI = new CUI.Select({element: this.customLinkStyleFieldSelectorString});
            }
/*
			var tagList = new CUI.Select({ element:'[data-rte-dialog=link] .anurag-coral-select-rte-link-style' });

            if (!this.anuragFieldCUI) {
                this.anuragFieldCUI = new CUI.Select({element: this.anuragFieldSelectorString});
            }
*/            
        },

        dlgToModel: function() {

            this.superClass.dlgToModel.call(this);

            var relField = this.getFieldByType("customLinkStyle");

            if(_.isEmpty(relField)){
                return;
            }

            var relVal = relField.val();

            if (_.isEmpty(relVal)) {
                return;
            }
 
            this.objToEdit.attributes["class"] = relVal;
        },

        dlgFromModel: function() {

            this.superClass.dlgFromModel.call(this);

            var customLinkStyleSelect = $(this.customLinkStyleFieldSelectorString).data("select");
            if(customLinkStyleSelect){
                var customLinkStyle = (this.objToEdit && this.objToEdit.attributes && this.objToEdit.attributes["class"] ? this.objToEdit.attributes["class"] : null);
                if(customLinkStyle){
					customLinkStyleSelect.setValue(customLinkStyle || '');
                }
            }


            /*var customLinkStyleField = this.getFieldByType("customLinkStyle");
			if (customLinkStyleField){
				var value = (this.objToEdit && this.objToEdit.attributes && this.objToEdit.attributes["class"] ? this.objToEdit.attributes["class"] : null);
                customLinkStyleField.val( value );
			}*/

        }
    });
 
    CUI.rte.ui.cui.CuiDialogHelper = new Class({
        extend: CUI.rte.ui.cui.CuiDialogHelper,
 
        toString: "EAEMCuiDialogHelper",
 
        instantiateDialog: function(dialogConfig) {
            var type = dialogConfig.type;
 
            if(type !== RTE_LINK_DIALOG){
                this.superClass.instantiateDialog.call(this, dialogConfig);
                return;
            }
 
            var $editable = $(this.editorKernel.getEditContext().root),
                $container = CUI.rte.UIUtils.getUIContainer($editable),
                dialog = new EAEMLinkBaseDialog();

            dialog.attach(dialogConfig, $container, this.editorKernel);

            return dialog;
        }
    });

    function toArray(obj, keyName, valueName) {
        if (!obj) {
            return null;
        }
        if (CUI.rte.Utils.isArray(obj)) {
            return obj;
        }
        if (typeof(obj) == "object") {
            var array = [ ];
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if (!keyName || !valueName) {
                        array.push(obj[key]);
                    } else {
                        var value = obj[key];
                        if (!!value && (value.constructor === Object)) {
                            array.push(obj[key]);
                        } else {
                            var convObj = { };
                            convObj[keyName] = key;
                            convObj[valueName] = value;
                            array.push(convObj);
                        }
                    }
                }
            }
            return array;
        }
        return [ obj ];
    }

    function getLinkRelOptionsHtml(styles){
		var html;
        console.log("Inside getLinkRelOptionsHtml() with styles:==>");
        console.log(styles);
        if(styles && styles.length > 0){
			html = 	'<div class="coral-RichText-dialog-columnContainer">' +
					'<div class="coral-RichText-dialog-column">' +
						'<span class="coral-Select coral-RichText-dialog-column--customStyleField coral-RichText-dialog-column--customLinkStyleField">' +
                            '<button type="button" class="coral-Select-button coral-MinimalButton">' +
                                '<span class="coral-Select-button-text"></span>' +
                            '</button>' +
                            '<select class="customLinkStyleDropDown coral-Select-select" data-type="customLinkStyle">' + 
                                '<option value="defaultRteLinkStyle">Link Style</option>';
                                var count = 0;
                                for (count = 0; count < styles.length; count++) {
                                    html = html + getOptionHtml(styles[count]);
                                }

            html = html + 
							'</select>' +
						'</span>' +
					'</div>' +
				'</div>';
        }



		/* 
        //Uncomment for AEM62
        var html =  "<div class='coral-RichText-dialog-columnContainer'>" +
                    "<div class='coral-RichText-dialog-column'>" +
                    "<coral-select data-type='class' placeholder='Link Type'>";

        var options = ["CTA Link", "Red Arrow Link", "Blue Arrow Link", "Red Solid Button", "Red Solid Button Large",
                        "Red Line Button", "Red Line Button Large", "Blue Solid Button", "Blue Solid Button Large", "Blue Line Button", "Blue Line Button Large", "White Solid Button" ];

        _.each(options, function(option){
            html = html + getOptionHtml(option);
        });

        html = html + "</coral-select></div></div>";


 		*/
        
        //Changes placeholder value from "Alt Text" to "aria-label"
        var titleField = $(".coral-RichText-dialog--link .coral-RichText-dialog-columnContainer .coral-RichText-dialog-column .coral-Form-field");
        if(titleField.length){
        	titleField[0].setAttribute("placeholder","aria-label");
        }
        
        return html;

        function getOptionHtml(option){
            return '<option value="'+option.cssName+'">'+option.text+'</option>';
			/* 
        	//Uncomment for AEM62
            return "<coral-select-item>" + option + "</coral-select-item>"
            */
        }
    }
 
    CUI.rte.ui.cui.CuiDialogHelper.eaemExtended = true;
})(jQuery);
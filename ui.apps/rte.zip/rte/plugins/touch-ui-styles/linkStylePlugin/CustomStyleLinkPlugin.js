/*************************************************************************
*
* Custom Style Link Plugin
* ___________________
*
* Font Color Plugin
*
* @author Anurag Kumar
*
*
**************************************************************************/
USB.rte.plugins.CustomStyleLinkPlugin = new Class({

    toString: "FontColorPlugin",

    extend: CUI.rte.plugins.LinkPlugin,



	notifyPluginConfig: function(pluginConfig) {
        this.superClass.notifyPluginConfig.call(this, pluginConfig);
        console.log(this.config);

        this.config = pluginConfig;
        this.config.linkDialogConfig.styles = this.config["styles"];
    },



});

// register plugin
CUI.rte.plugins.PluginRegistry.register("links", USB.rte.plugins.CustomStyleLinkPlugin);
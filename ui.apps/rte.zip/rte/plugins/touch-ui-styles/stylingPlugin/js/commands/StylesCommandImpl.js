/*************************************************************************
*
* Style Plugins
* ___________________
* Styles Command manager for following plugins:
* 1. fontsize
* 2. fontcolor
* 3. fontmisc
* 4. fonttype
* 5. ratesapikey
* 
* @author Anurag Kumar
* @since 22nd August 2017
* 
* @author Karthik Srinivasulu
* @since 6th May 2019
**************************************************************************/
USB.rte.commands.StylesCommandImpl = new Class({

    toString: "USBStylesCommand",

    extend: CUI.rte.commands.Command,

    isCommand: function(cmdStr) {
        var cmdLC = cmdStr.toLowerCase();
        return (cmdLC == "applystyle") || (cmdLC == "removestyle");
    },

    getProcessingOptions: function() {
        var cmd = CUI.rte.commands.Command;
        return cmd.PO_BOOKMARK | cmd.PO_SELECTION | cmd.PO_NODELIST;
    },

	/**
     * Formats the currently selected text fragment with the given CSS style.
     * <p>
     * The currently selected text will be surrounded with a <code>span</code> tag that
     * has the given style name as its <code>class</code> attribute..
     * <p>
     * Note that this method only works on text fragments that have no other styles
     * applied.
     * @private
     */
    addStyle: function(execDef) {
		var sel = CUI.rte.Selection;
        var com = CUI.rte.Common;
        var styleName = execDef.value;
        var selection = execDef.selection;
        var context = execDef.editContext;
        // handle DOM elements
        var selectedDom = sel.getSelectedDom(context, selection);
        var styleableObjects = CUI.rte.plugins.StylesPlugin.STYLEABLE_OBJECTS;
        if (selectedDom && com.isTag(selectedDom, styleableObjects)) {
            com.removeAllClasses(selectedDom);
            com.addClass(selectedDom, styleName);
            return;
        }
        // handle text fragments
		var nodeList = execDef.nodeList;
        console.log("is nodeList null?  ["+nodeList+"]");
        if (nodeList) {
            console.log("nodeList to be surrounded by span. []");
            console.log(nodeList)
            nodeList.surround(execDef.editContext, "span", {
                "className": styleName
            });
        }
    },

    /**
     * Removes the style of the text fragment that is under the current caret position.
     * <p>
     * This method does currently not work with selections. Therefore a selection is
     * collapsed to a single char if the method is called for a selection.
     * @private
     */
    removeStyle: function(execDef) {
        var com = CUI.rte.Common;
        var dpr = CUI.rte.DomProcessor;
        var sel = CUI.rte.Selection;
        var selection = execDef.selection;
        var context = execDef.editContext;
        var styleToRemove = execDef.value;
        var styleName, styleCnt, s;
        // handle DOM elements
        var selectedDom = sel.getSelectedDom(context, selection);
        var styleableObjects = CUI.rte.plugins.StylesPlugin.STYLEABLE_OBJECTS;
        if (selectedDom && com.isTag(selectedDom, styleableObjects)) {
            if (styleToRemove && !styleToRemove.styles) {
                com.removeClass(selectedDom, styleToRemove);
            } else if (styleToRemove && styleToRemove.styles) {
                styleCnt = styleToRemove.styles.length;
                for (s = 0; s < styleCnt; s++) {
                    styleName = styleToRemove.styles[s];
                    if ((typeof(styleName) == "object") && styleName.cssName) {
                        styleName = styleName.cssName;
                    }
                    if (com.hasCSS(selectedDom, styleName)) {
                        com.removeClass(selectedDom, styleName);
                    }
                }
            } else {
                com.removeAllClasses(selectedDom);
            }
            return;
        }
        // handle text selections
        var nodeList = execDef.nodeList;
        var spanTags = nodeList.getTags(context, [ {
                matcher: function(dom) {
                    return com.isTag(dom, "span");
                }
            } ], true);
        var spansToRemove = [ ];
        var spanCnt = spanTags.length;
        for (var spanIndex = 0; spanIndex < spanCnt; spanIndex++) {
            var spanToProcess = spanTags[spanIndex].dom;
            if (styleToRemove && !styleToRemove.styles) {
                if (com.hasCSS(spanToProcess, styleToRemove)) {
                    spansToRemove.push(spanToProcess);
                }
            } else if (styleToRemove && styleToRemove.styles) {
                styleCnt = styleToRemove.styles.length;
                for (s = 0; s < styleCnt; s++) {
                    styleName = styleToRemove.styles[s].cssName;
                    if (com.hasCSS(spanToProcess, styleName)) {
                        spansToRemove.push(spanToProcess);
                        break;
                    }
                }
            } else {
                if (spanToProcess.className) {
                    spansToRemove.push(spanToProcess);
                }
            }
        }
        var removeCnt = spansToRemove.length;
        for (var r = 0; r < removeCnt; r++) {
            var spanToRemove = spansToRemove[r];
            dpr.removeWithoutChildren(spanToRemove);
        }
    },

    execute: function(execDef) {
        switch (execDef.command.toLowerCase()) {
            case "applystyle":
                this.addStyle(execDef);
                break;
            case "removestyle":
                this.removeStyle(execDef);
                break;
        }
    },

    queryState: function(selectionDef, cmd) {
        // todo find a meaningful implementation -> list of span tags?
        return false;
    }
});


// register command
CUI.rte.commands.CommandRegistry.register("usbstyles", USB.rte.commands.StylesCommandImpl);
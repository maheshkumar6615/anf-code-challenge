/*************************************************************************
* Font Color Plugin
* ___________________
* Setting up classes
*
* @author Anurag Kumar
* @since 22nd August 2017
**************************************************************************/
var USB = USB || {};
USB.rte = USB.rte || {
    GROUP: "usb",

    // Commands
    COMMAND: {
   		STYLE: "usbstyles"
	},

    DEBUG: {
        ALL: false,
        STYLESELECTOR: false,
        TOOLKITIMPL: false,
        TOOLBARBUILDER: false,
        STYLECOMMAND: false,
        FONTCOLOR: false,
        FONTTYPE: false
    },

    // Features
    FEATURE: {
        FONT_COLOR: {
            NAME: "fontcolor",
            ID: "#fontcolor",
            POPID: "fontcolor:getStyles:styles-pulldown",
            TITLE : "fontcolor",
            ICON : "textColor"

        },
        FONT_SIZE: {
            NAME: "fontsize",
            ID: "#fontsize",
            POPID: "fontsize:getStyles:styles-pulldown",
            TITLE : "Fontsize",
            ICON : "confidenceFour"

        },
        FONT_MISC: {
            NAME: "fontmisc",
            ID: "#fontmisc",
            POPID: "fontmisc:getStyles:styles-pulldown",
            TITLE : "Fontmisc",
            ICON : "properties"

        },
        FONT_TYPE: {
            NAME: "fonttype",
            ID: "#fonttype",
            POPID: "fonttype:getStyles:styles-pulldown",
            TITLE : "Fonttype",
            ICON : "app"

        },
        RATES_APIKEY: {
            NAME: "ratesapikey",
            ID: "#ratesapikey",
            POPID: "ratesapikey:getStyles:styles-pulldown",
            TITLE : "RatesApiKey",
            ICON: "graphAreaStacked"
        }
    },
    //DEBUGGING: true,
    DEBUGGING: null,

    HIDE_OOTB_STYLES: true,
	//HIDE_OOTB_STYLES: false,

    STYLE_TAG: "span",

    STYLEABLE_OBJECTS: [
    	"img"
	]
};
USB.rte.commands = {};
USB.rte.plugins = {};
USB.rte.ui = {};
USB.rte.utils = {};


/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2012 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

  USB.rte.Utils = (function () {

    var i18nProvider = null;
    var getI18nProvider = function () {
      if (!i18nProvider) {
        i18nProvider = new USB.rte.I18nProvider();
      }
      return i18nProvider;
    };

    return {
      setI18nProvider: function (provider) {
        i18nProvider = provider;
      },

      i18n: function (id, values) {
          console.log("getting i18n");
        return getI18nProvider().getText(id, values);
      },

    };

  }());


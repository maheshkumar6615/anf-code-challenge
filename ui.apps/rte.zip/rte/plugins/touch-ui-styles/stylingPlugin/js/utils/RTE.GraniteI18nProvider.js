/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

USB.rte.GraniteI18nProvider = new Class({

  extend: CUI.rte.I18nProvider,

  _map: {

    "popover.trigger.plugins.Fontsize":
      Granite.I18n.get("Font Size"),
    "popover.trigger.plugins.Fontcolor":
      Granite.I18n.get("Font Color"),
    "popover.trigger.plugins.Fonttype":
      Granite.I18n.get("Font Type"),
    "popover.trigger.plugins.Fontmisc":
      Granite.I18n.get("Font Misc"),
       "popover.trigger.plugins.Format":
      Granite.I18n.get("Format"),
    "popover.trigger.plugins.Paraformat":
      Granite.I18n.get("Paragraph formats"),
    "popover.trigger.plugins.Justify":
      Granite.I18n.get("Justify"),
    "popover.trigger.plugins.Lists":
      Granite.I18n.get("Lists"),
    "popover.trigger.plugins.Styles":
      Granite.I18n.get("Styles"),
    "popover.trigger.plugins.Ratesapikey":
      Granite.I18n.get("RatesApiKey")

  },

  getText: function(id, values) {
    var text = id;
    if (this._map && this._map.hasOwnProperty(id)) {
      text = this._map[id];
    }
    if (values) {
      if (!CUI.rte.Utils.isArray(values)) {
        text = text.replace("{0}", values);
      } else {
        for (var s = 0; s < values.length; s++) {
          text = text.replace("{" + s + "}", values[s])
        }
      }
    }
    return text;
  }

});

USB.rte.Utils.setI18nProvider(new USB.rte.GraniteI18nProvider());

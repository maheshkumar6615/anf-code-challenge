/*************************************************************************
*
* RTE Plugins
* ___________________
*
* Extend the toolkit implementation for custom toolbar builder and dialog manager
*
* @author Anurag Kumar
*
*
**************************************************************************/
USB.rte.ui.ToolkitImpl = new Class({

    toString: "USBToolkitImpl",

    extend: CUI.rte.ui.cui.ToolkitImpl,

    createToolbarBuilder: function() {
        return new USB.rte.ui.CuiToolbarBuilder();
    }
});

CUI.rte.ui.ToolkitRegistry.register("cui", USB.rte.ui.ToolkitImpl);
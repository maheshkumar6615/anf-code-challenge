/*************************************************************************
 *
 * RTE Plugins
 * ___________________
 *
 * Font Color Plugin
 *
 * @author Anurag Kumar
 *
 *
 **************************************************************************/
(function(CUI) {
    //'use strict';
    USB.rte.plugins.FontColorPlugin = new Class({

        toString: "FontColorPlugin",

        extend: CUI.rte.plugins.Plugin,

        /**
         * @private
         */
        cachedStyles: null,

        /**
         * @private
         */
        stylesUI: null,
        /**
         * @private
         */
        icon: USB.rte.FEATURE.FONT_COLOR.ICON,

        /**
         * @private
         */
        tooltip: USB.rte.FEATURE.FONT_COLOR.TITLE,

        getIcon: function() {
            return USB.rte.FEATURE.FONT_COLOR.ICON;
        },
        getTooltip: function() {
            return USB.rte.FEATURE.FONT_COLOR.TITLE;
        },

        getFeatures: function() {
            return [USB.rte.FEATURE.FONT_COLOR.NAME];
        },

        reportStyles: function() {
            return [{
                "type": "text",
                "styles": this.getStyles()
            }];
        },

        getStyles: function() {
            var com = CUI.rte.Common;
            if (!this.cachedStyles) {
                this.cachedStyles = this.config.styles;
                if (this.cachedStyles) {
                    // take styles from config
                    com.removeJcrData(this.cachedStyles);
                    this.cachedStyles = com.toArray(this.cachedStyles, "cssName", "text");
                } else {
                    this.cachedStyles = [];
                }
            }
            if (USB.rte.DEBUGGING) {
                console.log("gonna returning cachedStyles");
                console.log(this.cachedStyles);
            }
            this.getTooltip();
            this.getIcon();
            return this.cachedStyles;
        },

        setStyles: function(styles) {
            this.cachedStyles = styles;
        },

        hasStylesConfigured: function() {
            return !!this.config.styles;
        },

        initializeUI: function(tbGenerator, options) {
            var plg = CUI.rte.plugins;
            if (this.isFeatureEnabled(USB.rte.FEATURE.FONT_COLOR.NAME)) {
                this.stylesUI = new tbGenerator.createUSBStyleSelector(USB.rte.FEATURE.FONT_COLOR.NAME, this, this.tooltip,
                    this.getStyles());
                tbGenerator.addElement(USB.rte.FEATURE.FONT_COLOR.NAME, plg.Plugin.SORT_STYLES, this.stylesUI, 10);
            }
        },

        notifyPluginConfig: function(pluginConfig) {
            pluginConfig = pluginConfig || {};
            CUI.rte.Utils.applyDefaults(pluginConfig, {});
            this.config = pluginConfig;
        },

        execute: function(cmdId, styleDef) {
            if (!this.stylesUI) {
                return;
            }
            var cmd = null;
            var tagName = undefined;
            var className = undefined;
            //console.log("Inside FontCOlOrPlugin.execute with cmdId.toLowerCase():"+cmdId.toLowerCase());
            switch (cmdId.toLowerCase()) {
                case "applystyle":
                    cmd = "fontcolor";
                    tagName = "span";
                    className = (styleDef != null ? styleDef :
                        this.stylesUI.getSelectedStyle());
                    break;
            }
            if (cmd && tagName && className) {
                this.editorKernel.relayCmd(cmd, {
                    "tag": tagName,
                    "attributes": {
                        "class": className
                    }
                });
            }
        },

        /**
         * @private
         */
        /*getStyleId: function(dom) {

        var tagName = dom.tagName.toLowerCase();
        var styles = this.getStyles();
        var stylesCnt = styles.length;
        for (var f = 0; f < stylesCnt; f++) {
            var styleDef = styles[f];
            //TODO: We need to handle span class, not tag
            if (styleDef.tag && (styleDef.tag == tagName)) {
                return styleDef.tag;
            }
        }
        return null;
    },
*/

        updateState: function(selDef) {
            if (!this.stylesUI) {
                return;
            }
            //console.log("Inside updateState");

            var com = CUI.rte.Common;
            var styles = selDef.startStyles;
            var actualStyles = [];
            var s;
            var styleableObject = selDef.selectedDom;
            //console.log("selDef container is: ");
            //console.log(selDef.containerList[0].tagName);
            //console.log(selDef);
            if (styleableObject) {
                if (!CUI.rte.Common.isTag(selDef.selectedDom,
                        CUI.rte.plugins.StylesPlugin.STYLEABLE_OBJECTS)) {
                    styleableObject = null;
                }
            }
            var stylesDef = this.getStyles();
            var styleCnt = stylesDef.length;

            if (USB.rte.HIDE_OOTB_STYLES) {
                //console.log(ootbStyles);
                var ootbStyles = $('.coral-RichText-ui .coral-RichText-toolbar button.coral-RichText--trigger[data-action="#styles"]');
                ootbStyles.hide();
            }

            // logic to hide unsupported styles for this tag
            var thisContainer = selDef.containerList[0].tagName;
            for (counter = 0; counter < styleCnt; counter++) {
                var styleItemButton = $("button[data-action='styles#" + stylesDef[counter].cssName + "']");
                styleItemButton.show();
                if (stylesDef[counter] && stylesDef[counter].tagsSupported) {
                    var tagsSupportedArr = stylesDef[counter].tagsSupported;
                    if (tagsSupportedArr.indexOf(thisContainer) == -1) {
                        styleItemButton.hide();
                    }
                }
            }
            // logic to hide unsupported styles for this tag ends

            if (styleableObject) {
                for (s = 0; s < styleCnt; s++) {
                    var styleName = stylesDef[s].cssName;
                    if (com.hasCSS(styleableObject, styleName)) {
                        actualStyles.push({
                            "className": styleName
                        });
                    }
                }
            } else {
                var checkCnt = styles.length;
                for (var c = 0; c < checkCnt; c++) {
                    var styleToProcess = styles[c];
                    var individualStyles = styleToProcess.className.split(" ");
                    // for(var t = 0; t < individualStyles.length; t++) {
                    for (s = 0; s < styleCnt; s++) {
                        if (stylesDef[s].cssName === styleToProcess.className) {
                            actualStyles.push(styleToProcess);
                            break;
                        }
                    }
                    // }
                }
            }
            this.stylesUI.selectStyles(actualStyles, selDef);
        }
    });

    // register plugin
    CUI.rte.plugins.PluginRegistry.register("fontcolor", USB.rte.plugins.FontColorPlugin);
}(window.CUI));